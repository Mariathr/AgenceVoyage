package com.formation.app.model;

public class Trip {
    private Long id;
    private  Long idDepart;
    private Long idArrivee;
    private Float prix;

}
