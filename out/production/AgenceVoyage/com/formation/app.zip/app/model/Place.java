package com.formation.app.model;

public class Place {
    private Long id;
    private String nom;
}
