package com.formation.app.dao.jdbc;

import com.formation.app.util.ConnectionManager;

public abstract class JdbcDao  {
  protected ConnectionManager connection;


}
